(function () {
  'use strict';

  /* =====================================================================
     PencilMotion EDU - Fasa 1E: personalisasi, huruf besar/kecil dan identiti pembangun

     Prinsip kestabilan:
     1. Satu masa projek (state.t) mengawal segala-galanya. Tiada setTimeout
        atau setInterval untuk animasi; hanya satu gelung requestAnimationFrame.
     2. render(t) ialah fungsi tulen: bingkai yang sama dihasilkan bagi masa
        yang sama, jadi Main, Jeda, Ulang dan seret garis masa sentiasa tepat.
     3. Laluan SVG setiap adegan dibina SEKALI (semasa teks atau hiasan
        berubah), bukan pada setiap bingkai. Setiap bingkai hanya menukar
        stroke-dashoffset, kedudukan pensel dan opacity.
     ===================================================================== */

  /* ---------- Tetapan ---------- */
  const NS = 'http://www.w3.org/2000/svg';
  const VW = 540;
  const MAX_W = 430;
  const MIN_SCALE = 0.26;
  const MAX_SCALE = 1.1;
  const GAP_U = 20;
  const PENCIL_SCALE = 0.8;
  const BASE_ANGLE = 36;
  const WRITE_SPEED = 0.5;

  const MAX_SCENES = 5;
  const MAX_CHARS = 120;
  const TR = 0.5;        // tempoh peralihan fade antara adegan (saat)
  const ENTER = 1.1;     // pensel masuk dari kanan
  const EXIT = 0.9;      // pensel keluar ke kanan
  const STORE_KEY = 'pencilmotion-edu-1e';
  const LEGACY_KEY = 'pencilmotion-edu-1c';
  const DECOS = ['none', 'underline', 'full'];
  const CASES = ['asal', 'besar', 'kecil'];
  const REGIONS = {
    none: { cy: 470, maxH: 700 },
    underline: { cy: 440, maxH: 600 },
    full: { cy: 385, maxH: 450 }
  };

  const PALETTES = {
    ink: [['Hitam', '#111111'], ['Biru', '#1f5fd6'], ['Merah', '#e0302f'], ['Hijau', '#1b9a4b']],
    pencil: [['Biru', '#1f5fd6'], ['Merah', '#e0302f'], ['Hijau', '#1b9a4b'], ['Hitam', '#1b1b1b'], ['Kuning', '#f2b705']],
    bg: [['Krim', '#fbf3dc'], ['Putih', '#ffffff'], ['Biru pastel', '#dcebff'], ['Hijau pastel', '#dcf2de'], ['Merah jambu pastel', '#ffe0de'], ['Biru navy', '#14284b']]
  };
  const PALETTE_NAMES = { ink: 'tulisan', pencil: 'pensel', bg: 'latar' };

  const SAMPLE = {
    pencil: '#1f5fd6',
    credit: true,
    scenes: [
      { text: 'TEKNIK SIBAK', bg: '#fbf3dc', ink: '#111111', speed: 1, pause: 1.5, deco: 'underline', caseMode: 'asal' },
      { text: 'SIAPA - BAGAIMANA - KESAN', bg: '#dcebff', ink: '#1f5fd6', speed: 1, pause: 1.5, deco: 'underline', caseMode: 'asal' },
      { text: 'JOM KUASAI KMK!', bg: '#fbf3dc', ink: '#111111', speed: 1, pause: 2, deco: 'full', caseMode: 'asal' }
    ]
  };

  /* ---------- Fon garisan tunggal (tinggi 110; w = lebar kotak glif) ---------- */
  const GLYPHS = {
    ' ': { w: 26, s: [] },
    A: { w: 60, s: ['M3 110 L30 0 L57 110', 'M14 74 H46'] },
    B: { w: 56, s: [
      'M4 110 V0 H28 C46 0 50 14 50 27 C50 42 42 55 26 55 H4',
      'M4 55 H28 C48 55 54 69 54 83 C54 100 44 110 26 110 H4'
    ] },
    C: { w: 56, s: ['M52 18 C46 6 38 0 28 0 C10 0 2 24 2 55 C2 86 10 110 28 110 C38 110 46 104 52 92'] },
    D: { w: 56, s: ['M4 0 V110 H22 C46 110 54 86 54 55 C54 24 46 0 22 0 H4'] },
    E: { w: 48, s: ['M44 0 H4 V110 H44', 'M4 55 H36'] },
    F: { w: 46, s: ['M44 0 H4 V110', 'M4 52 H34'] },
    G: { w: 60, s: ['M54 20 C48 6 40 0 30 0 C12 0 2 24 2 55 C2 86 12 110 30 110 C46 110 56 96 56 70 V58 H32'] },
    H: { w: 56, s: ['M4 0 V110', 'M52 0 V110', 'M4 55 H52'] },
    I: { w: 12, s: ['M6 0 V110'] },
    J: { w: 46, s: ['M40 0 V72 C40 96 30 108 18 108 C8 108 3 102 2 92'] },
    K: { w: 54, s: ['M4 0 V110', 'M50 0 L5 64 L52 110'] },
    L: { w: 44, s: ['M4 0 V110 H42'] },
    M: { w: 70, s: ['M3 110 V0 L35 72 L67 0 V110'] },
    N: { w: 60, s: ['M4 110 V0 L56 110 V0'] },
    O: { w: 62, s: ['M31 0 C12 0 2 22 2 55 C2 88 12 110 31 110 C50 110 60 88 60 55 C60 22 50 0 31 0'] },
    P: { w: 52, s: ['M4 110 V0 H28 C46 0 50 14 50 27 C50 42 42 55 26 55 H4'] },
    Q: { w: 64, s: [
      'M31 0 C12 0 2 22 2 55 C2 88 12 110 31 110 C50 110 60 88 60 55 C60 22 50 0 31 0',
      'M38 78 L60 112'
    ] },
    R: { w: 54, s: [
      'M4 110 V0 H28 C46 0 50 14 50 27 C50 42 42 55 26 55 H4',
      'M26 55 L52 110'
    ] },
    S: { w: 52, s: ['M48 16 C44 6 36 0 26 0 C12 0 4 10 4 24 C4 40 14 46 26 52 C40 59 48 66 48 82 C48 100 38 110 26 110 C14 110 6 104 2 92'] },
    T: { w: 56, s: ['M2 0 H54', 'M28 0 V110'] },
    U: { w: 56, s: ['M4 0 V80 C4 100 14 110 28 110 C42 110 52 100 52 80 V0'] },
    V: { w: 60, s: ['M2 0 L30 110 L58 0'] },
    W: { w: 84, s: ['M2 0 L22 110 L42 30 L62 110 L82 0'] },
    X: { w: 58, s: ['M3 0 L55 110', 'M55 0 L3 110'] },
    Y: { w: 58, s: ['M3 0 L29 56 L55 0', 'M29 56 V110'] },
    Z: { w: 54, s: ['M4 0 H50 L4 110 H50'] },
    '0': { w: 50, s: ['M25 0 C9 0 2 22 2 55 C2 88 9 110 25 110 C41 110 48 88 48 55 C48 22 41 0 25 0'] },
    '1': { w: 30, s: ['M4 22 L24 0 V110'] },
    '2': { w: 52, s: ['M4 22 C6 8 14 0 26 0 C40 0 48 10 48 26 C48 44 30 64 4 110 H50'] },
    '3': { w: 50, s: ['M4 14 C8 4 16 0 24 0 C38 0 46 10 46 25 C46 40 36 50 20 52 C38 54 48 64 48 82 C48 100 38 110 24 110 C14 110 6 104 2 94'] },
    '4': { w: 54, s: ['M40 110 V0 L2 76 H52'] },
    '5': { w: 50, s: ['M46 0 H8 L4 50 C10 44 18 42 26 42 C40 42 48 54 48 74 C48 96 38 110 24 110 C14 110 6 104 2 94'] },
    '6': { w: 50, s: ['M44 8 C38 2 32 0 26 0 C10 0 2 26 2 62 C2 96 10 110 26 110 C40 110 48 98 48 80 C48 62 40 52 26 52 C14 52 4 62 2 74'] },
    '7': { w: 50, s: ['M2 0 H48 L18 110'] },
    '8': { w: 52, s: ['M26 0 C12 0 6 10 6 25 C6 40 16 50 26 54 C38 58 48 68 48 84 C48 100 38 110 26 110 C14 110 4 100 4 84 C4 68 14 58 26 54 C38 50 46 40 46 25 C46 10 40 0 26 0'] },
    '9': { w: 50, s: ['M6 102 C12 108 18 110 24 110 C40 110 48 84 48 48 C48 14 40 0 24 0 C10 0 2 12 2 30 C2 48 10 58 24 58 C36 58 46 48 48 36'] },
    a: { w: 46, s: ['M40 54 C34 46 28 42 21 42 C9 42 2 56 2 76 C2 96 9 110 21 110 C29 110 36 105 40 96', 'M40 42 V110'] },
    b: { w: 46, s: ['M4 0 V110', 'M4 60 C10 46 18 42 25 42 C38 42 44 56 44 76 C44 96 38 110 25 110 C18 110 10 106 4 92'] },
    c: { w: 42, s: ['M38 54 C33 46 27 42 21 42 C9 42 2 56 2 76 C2 96 9 110 21 110 C28 110 34 106 38 98'] },
    d: { w: 46, s: ['M42 54 C36 46 30 42 23 42 C10 42 2 56 2 76 C2 96 10 110 23 110 C31 110 37 105 42 96', 'M42 0 V110'] },
    e: { w: 46, s: ['M2 76 H42 C42 54 34 42 22 42 C9 42 2 56 2 76 C2 96 9 110 22 110 C32 110 39 105 42 96'] },
    f: { w: 34, s: ['M32 6 C28 1 23 0 19 0 C11 0 8 8 8 20 V110', 'M0 42 H30'] },
    g: { w: 46, s: ['M42 54 C36 46 30 42 23 42 C10 42 2 56 2 76 C2 96 10 110 23 110 C31 110 37 105 42 96', 'M42 42 V134 C42 146 34 150 22 150 C12 150 6 147 2 140'] },
    h: { w: 46, s: ['M4 0 V110', 'M4 66 C10 48 18 42 26 42 C38 42 42 52 42 66 V110'] },
    i: { w: 12, s: ['M6 42 V110', 'M6 14 V16'] },
    j: { w: 24, s: ['M20 42 V136 C20 146 12 150 4 148', 'M20 14 V16'] },
    k: { w: 40, s: ['M4 0 V110', 'M36 42 L5 78 L38 110'] },
    l: { w: 12, s: ['M6 0 V110'] },
    m: { w: 70, s: ['M4 42 V110', 'M4 62 C8 46 15 42 22 42 C32 42 35 52 35 66 V110', 'M35 62 C39 46 46 42 53 42 C63 42 66 52 66 66 V110'] },
    n: { w: 46, s: ['M4 42 V110', 'M4 62 C8 48 16 42 24 42 C36 42 42 52 42 66 V110'] },
    o: { w: 48, s: ['M24 42 C10 42 2 56 2 76 C2 96 10 110 24 110 C38 110 46 96 46 76 C46 56 38 42 24 42'] },
    p: { w: 46, s: ['M4 42 V150', 'M4 58 C10 46 17 42 24 42 C37 42 44 56 44 76 C44 96 37 110 24 110 C17 110 10 106 4 94'] },
    q: { w: 46, s: ['M42 54 C36 46 30 42 23 42 C10 42 2 56 2 76 C2 96 10 110 23 110 C31 110 37 105 42 96', 'M42 42 V150'] },
    r: { w: 34, s: ['M4 42 V110', 'M4 64 C8 50 16 42 26 42 C29 42 31 43 32 44'] },
    s: { w: 40, s: ['M36 52 C33 45 28 42 20 42 C10 42 6 48 6 55 C6 64 14 67 20 70 C30 74 36 78 36 90 C36 104 28 110 20 110 C11 110 5 106 2 98'] },
    t: { w: 32, s: ['M12 14 V96 C12 106 16 110 24 110 C27 110 29 109 30 108', 'M2 42 H28'] },
    u: { w: 46, s: ['M4 42 V84 C4 102 12 110 24 110 C34 110 41 103 42 92', 'M42 42 V110'] },
    v: { w: 46, s: ['M2 42 L23 110 L44 42'] },
    w: { w: 70, s: ['M2 42 L18 110 L35 56 L52 110 L68 42'] },
    x: { w: 44, s: ['M3 42 L41 110', 'M41 42 L3 110'] },
    y: { w: 46, s: ['M3 42 L24 106', 'M44 42 L20 124 C15 138 10 148 2 148'] },
    z: { w: 40, s: ['M4 42 H36 L4 110 H38'] },
    '.': { w: 10, s: ['M5 104 V106'] },
    ',': { w: 14, s: ['M8 98 L8 104 L3 116'] },
    '!': { w: 10, s: ['M5 0 V74', 'M5 103 V105'] },
    '?': { w: 48, s: ['M4 22 C4 8 12 0 24 0 C38 0 44 10 44 24 C44 40 28 46 24 62 V72', 'M24 102 V104'] },
    ':': { w: 10, s: ['M5 34 V36', 'M5 102 V104'] },
    ';': { w: 14, s: ['M8 34 V36', 'M8 96 L8 102 L3 114'] },
    '-': { w: 34, s: ['M4 62 H30'] },
    "'": { w: 10, s: ['M5 0 V22'] },
    '"': { w: 26, s: ['M6 0 V22', 'M20 0 V22'] },
    '(': { w: 22, s: ['M18 0 C4 24 4 86 18 110'] },
    ')': { w: 22, s: ['M4 0 C18 24 18 86 4 110'] },
    '/': { w: 34, s: ['M30 0 L4 110'] },
    '&': { w: 62, s: ['M58 110 L20 52 C8 34 14 0 32 0 C48 0 52 22 36 40 C18 62 4 72 4 88 C4 104 16 110 28 110 C42 110 52 98 58 78'] },
    '+': { w: 50, s: ['M25 30 V80', 'M2 55 H48'] },
    '=': { w: 46, s: ['M3 42 H43', 'M3 72 H43'] },
    '%': { w: 70, s: [
      'M62 0 L8 110',
      'M18 0 C8 0 4 6 4 14 C4 22 8 28 18 28 C28 28 32 22 32 14 C32 6 28 0 18 0',
      'M52 80 C42 80 38 86 38 94 C38 102 42 108 52 108 C62 108 66 102 66 94 C66 86 62 80 52 80'
    ] }
  };

  /* ---------- Alat kecil ---------- */
  const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };
  const easeOutCubic = (t) => 1 - Math.pow(1 - t, 3);
  const easeInCubic = (t) => t * t * t;
  const easeInOutCubic = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
  const easeOutBack = (t) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
  const drawEase = (u) => 0.55 * u + 0.45 * (u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2);
  const scalePath = (d, k) => d.replace(/-?\d*\.?\d+/g, (n) => String(+(parseFloat(n) * k).toFixed(2)));
  const luminance = (hex) => {
    const n = parseInt(hex.slice(1), 16);
    return (0.299 * ((n >> 16) & 255) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255)) / 255;
  };
  const isHex = (v) => typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v);
  const fmt = (n) => n.toFixed(1);

  function mk(tag, attrs, parent) {
    const e = document.createElementNS(NS, tag);
    for (const k in attrs) e.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(e);
    return e;
  }

  // Tetapkan atribut hanya jika nilai berubah (kurangkan kerja DOM setiap bingkai)
  function setA(el, k, v) {
    const key = '__' + k;
    if (el[key] === v) return;
    el[key] = v;
    el.setAttribute(k, v);
  }

  const $ = (s) => document.querySelector(s);

  /* ---------- Rujukan DOM ---------- */
  const stageEl = $('#stage');
  const bgA = $('#bgA');
  const bgB = $('#bgB');
  const sceneLayer = $('#sceneLayer');
  const groupsLayer = $('#sceneGroups');
  const pencil = $('#pencil');
  const pencilShadow = $('#pencilShadow');
  const bookEl = $('#book');
  const starEl = $('#star');
  const creditG = $('#creditG');
  const creditText = $('#creditText');

  const sceneList = $('#sceneList');
  const sceneCount = $('#sceneCount');
  const btnAdd = $('#btnAdd');
  const btnDup = $('#btnDup');
  const btnDel = $('#btnDel');
  const btnUp = $('#btnUp');
  const btnDown = $('#btnDown');
  const btnUndo = $('#btnUndo');

  const editorTitle = $('#editorTitle');
  const textInput = $('#textInput');
  const charCount = $('#charCount');
  const btnGenerate = $('#btnGenerate');
  const msgEl = $('#msg');
  const sceneSpeed = $('#sceneSpeed');
  const sceneSpeedText = $('#sceneSpeedText');
  const scenePause = $('#scenePause');
  const scenePauseText = $('#scenePauseText');
  const sceneDeco = $('#sceneDeco');

  const modeAll = $('#modeAll');
  const modeScene = $('#modeScene');
  const btnPlay = $('#btnPlay');
  const btnPause = $('#btnPause');
  const btnReplay = $('#btnReplay');
  const strip = $('#strip');
  const scrub = $('#scrub');
  const infoScene = $('#infoScene');
  const infoTime = $('#infoTime');
  const infoTotal = $('#infoTotal');
  const stateText = $('#stateText');
  const stageCaption = $('#stageCaption');
  const rate = $('#rate');
  const rateText = $('#rateText');

  const projBox = $('#projBox');
  const btnDownload = $('#btnDownload');
  const btnCopy = $('#btnCopy');
  const btnSample = $('#btnSample');
  const fileImport = $('#fileImport');
  const importText = $('#importText');
  const btnImportText = $('#btnImportText');
  const projMsg = $('#projMsg');

  /* ---------- Keadaan projek ---------- */
  let uidN = 0;
  const uid = () => 's' + (++uidN) + '_' + Math.random().toString(36).slice(2, 6);

  let scenes = [];                 // model: { id, text, bg, ink, speed, pause, deco }
  const compiled = new Map();      // id -> laluan SVG dan garis masa adegan
  const settings = { pencil: '#1f5fd6', credit: true };
  let starts = [];                 // masa mula setiap adegan dalam masa projek
  let total = 0;                   // jumlah tempoh projek
  let lastDeleted = null;

  const state = {
    t: 0, playing: false, rate: 1, last: 0, raf: 0,
    mode: 'all', sel: 0, showcase: false, touched: false
  };

  const cs = (i) => compiled.get(scenes[i].id);

  /* ---------- Normalisasi dan susun atur teks ---------- */
  // Huruf besar/kecil dikekalkan seperti ditaip (mod 'asal'); aksara yang tidak disokong dilaporkan, bukan dibuang senyap
  function normalizeText(raw, mode) {
    const unsupported = [], mapped = [];
    const pre = String(raw).replace(/[\u2018\u2019`\u00b4]/g, "'")
      .replace(/[\u201c\u201d]/g, '"')
      .replace(/[\u2013\u2014]/g, '-')
      .replace(/\u2026/g, '...')
      .replace(/[\t\u00a0]/g, ' ');
    let out = '';
    Array.from(pre).forEach(function (c) {
      if (GLYPHS[c] || c === '\n' || c === '\r') { out += c; return; }
      const base = c.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
      if (base !== c && base.length && Array.from(base).every(function (b) { return GLYPHS[b]; })) {
        out += base;
        if (mapped.indexOf(c) < 0) mapped.push(c);
        return;
      }
      if (unsupported.indexOf(c) < 0) unsupported.push(c);
    });
    if (mode === 'besar') out = out.toUpperCase();
    else if (mode === 'kecil') out = out.toLowerCase();
    const paras = out.split(/\r?\n/).map(function (line) { return line.replace(/ +/g, ' ').trim(); })
      .filter(function (p) { return p.length > 0; });
    return { paras: paras, unsupported: unsupported, mapped: mapped };
  }

  const advance = (ch, s) => (GLYPHS[ch].w + GAP_U) * s;
  const seqWidth = (chars, s) => chars.reduce((a, c) => a + advance(c, s), 0) - GAP_U * s;
  // Huruf berekor (g, j, p, q, y) turun 40 unit di bawah garis dasar; koma dan titik koma turun 8 unit
  const lineDesc = (chars) => (chars.some(function (c) { return 'gjpqy'.indexOf(c) >= 0; }) ? 40
    : (chars.some(function (c) { return c === ',' || c === ';'; }) ? 8 : 0));
  function layoutMetrics(lines) {
    return { gapU: lines.some(function (l) { return lineDesc(l) >= 40; }) ? 66 : 55, lastDesc: lineDesc(lines[lines.length - 1]) };
  }
  function blockHeight(lines, s) {
    const m = layoutMetrics(lines), n = lines.length;
    return (n * 110 + (n - 1) * m.gapU + m.lastDesc) * s;
  }

  // Tanda sengkang berdiri sendiri dilekatkan pada perkataan sebelumnya supaya tidak memulakan baris
  const GLUE = ['-', '&', '/', '+', '='];
  function tokenize(p) {
    const out = [];
    p.split(' ').forEach(function (w) {
      if (GLUE.indexOf(w) >= 0 && out.length) out[out.length - 1] += ' ' + w;
      else out.push(w);
    });
    return out;
  }

  function wrapParas(paras, s, split) {
    const lines = [];
    let tooWide = false;
    paras.forEach(function (p) {
      let cur = [];
      const flush = function () { if (cur.length) { lines.push(cur); cur = []; } };
      tokenize(p).forEach(function (word) {
        const wc = Array.from(word);
        if (seqWidth(wc, s) > MAX_W) {
          if (!split) {
            tooWide = true;
          } else {
            flush();
            let chunk = [];
            wc.forEach(function (c) {
              if (chunk.length && seqWidth(chunk.concat([c]), s) > MAX_W) { lines.push(chunk); chunk = []; }
              chunk.push(c);
            });
            cur = chunk;
            return;
          }
        }
        if (!cur.length) cur = wc;
        else if (seqWidth(cur.concat([' '], wc), s) <= MAX_W) cur = cur.concat([' '], wc);
        else { flush(); cur = wc; }
      });
      flush();
    });
    return { lines: lines, tooWide: tooWide };
  }

  function chooseLayout(paras, region) {
    let s = MAX_SCALE;
    while (s >= MIN_SCALE) {
      const r = wrapParas(paras, s, false);
      if (!r.tooWide && blockHeight(r.lines, s) <= region.maxH) return { s: s, lines: r.lines };
      s = Math.round((s - 0.02) * 100) / 100;
    }
    const r = wrapParas(paras, MIN_SCALE, true);
    return { s: MIN_SCALE, lines: r.lines };
  }

  /* ---------- Binaan laluan SVG bagi satu adegan (dilakukan sekali) ---------- */
  const shadowColor = (bg) => (luminance(bg) < 0.45 ? 'rgba(0,0,0,0.38)' : 'rgba(70,45,10,0.17)');
  const underlineColor = (ink) => (ink.toLowerCase() === '#1b9a4b' ? '#1f5fd6' : '#1b9a4b');

  function pointAt(s, L) {
    const p = s.el.getPointAtLength(clamp(L, 0, s.len));
    return { x: p.x + s.ox, y: p.y + s.oy };
  }

  function addStroke(C, sc, d, ox, oy, width, deco) {
    const common = {
      d: d, fill: 'none', 'stroke-linecap': 'round', 'stroke-linejoin': 'round',
      'stroke-width': width.toFixed(2), visibility: 'hidden'
    };
    const sh = mk('path', Object.assign({}, common, {
      stroke: shadowColor(sc.bg),
      transform: 'translate(' + (ox + 4) + ' ' + (oy + 6) + ')'
    }), C.shL);
    const el = mk('path', Object.assign({}, common, {
      stroke: deco ? underlineColor(sc.ink) : sc.ink,
      transform: 'translate(' + ox + ' ' + oy + ')'
    }), C.inL);
    const s = { el: el, sh: sh, len: el.getTotalLength(), ox: ox, oy: oy, p: -1, deco: !!deco, start: null, end: null };
    s.start = pointAt(s, 0);
    s.end = pointAt(s, s.len);
    C.strokes.push(s);
  }

  function buildStrokes(C, sc, layout) {
    const s = layout.s;
    const region = REGIONS[sc.deco];
    const lineH = 110 * s;
    const met = layoutMetrics(layout.lines);
    const top0 = region.cy - blockHeight(layout.lines, s) / 2;
    const sw = clamp(14.4 * s, 4.5, 16);
    let last = null;

    layout.lines.forEach(function (chars, li) {
      const lw = seqWidth(chars, s);
      const y = top0 + li * (110 + met.gapU) * s;
      let x = (VW - lw) / 2;
      chars.forEach(function (c) {
        GLYPHS[c].s.forEach(function (d) { addStroke(C, sc, scalePath(d, s), x, y, sw, false); });
        x += advance(c, s);
      });
      const bottomD = y + lineH + lineDesc(chars) * s;
      C.lineBoxes.push({ x0: (VW - lw) / 2, x1: (VW + lw) / 2, top: y, base: y + lineH, bottom: bottomD });
      last = { w: lw, bottom: bottomD };
    });

    if (sc.deco !== 'none' && last) {
      const kk = clamp(s / 0.9, 0.5, 1.1);
      const seg = 40 * kk;
      const n = Math.max(2, Math.round(last.w / seg));
      const x0 = VW / 2 - (n * seg) / 2;
      let d = 'M' + x0.toFixed(2) + ' 0 q' + (seg / 2).toFixed(2) + ' ' + (-16 * kk).toFixed(2) + ' ' + seg.toFixed(2) + ' 0';
      for (let i = 1; i < n; i++) d += ' t' + seg.toFixed(2) + ' 0';
      addStroke(C, sc, d, 0, last.bottom + clamp(44 * kk, 26, 52), Math.max(6, 11 * kk), true);
    }
  }

  // Segmen mentah (berat relatif) dikira sekali; masa sebenar dikira oleh retime()
  function buildRaw(C) {
    const raw = [];
    C.strokes.forEach(function (s, i) {
      if (i > 0) {
        const a = C.strokes[i - 1].end, b = s.start;
        const dist = Math.hypot(b.x - a.x, b.y - a.y);
        raw.push({ kind: 'travel', a: a, b: b, dist: dist, w: 0.06 + dist / 1500, t0: 0, t1: 0 });
      }
      raw.push({ kind: 'draw', s: s, w: s.len / 340 + 0.02, t0: 0, t1: 0 });
    });
    C.timeline = raw;
    C.rawSum = raw.reduce(function (x, r) { return x + r.w; }, 0);
  }

  // Garis masa tempatan adegan: masuk, tulis, keluar, ikon penutup, jeda
  function retime(C, sc) {
    const speed = clamp(sc.speed, 0.25, 2);
    const W = clamp(C.rawSum * WRITE_SPEED, 2.5, 45) / speed;
    const k = W / C.rawSum;
    const T = { enterEnd: ENTER, writeEnd: ENTER + W, exitEnd: ENTER + W + EXIT };

    let t = T.enterEnd;
    C.timeline.forEach(function (r) { r.t0 = t; t += r.w * k; r.t1 = t; });
    C.timeline[C.timeline.length - 1].t1 = T.writeEnd;

    if (sc.deco === 'full') {
      C.iconT = { book: T.writeEnd + 0.1, star: T.writeEnd + 0.5, spark: T.writeEnd + 0.9 };
      C.contentEnd = T.writeEnd + 2.3;
    } else {
      C.iconT = { book: Infinity, star: Infinity, spark: Infinity };
      C.contentEnd = T.exitEnd;
    }
    C.T = T;
    C.dur = C.contentEnd + clamp(sc.pause, 0, 5);
  }

  function buildCompiled(sc) {
    const norm = normalizeText(sc.text, sc.caseMode);
    if (!norm.paras.length) return { C: null, norm: norm };
    const g = mk('g', { visibility: 'hidden', 'data-id': sc.id }, groupsLayer);
    const C = {
      id: sc.id, text: sc.text, deco: sc.deco, caseMode: sc.caseMode, lineBoxes: [], g: g,
      shL: mk('g', {}, g), inL: mk('g', {}, g),
      strokes: [], timeline: [], rawSum: 1, T: null, iconT: null, contentEnd: 0, dur: 0,
      lines: 0, count: 0, unsupported: norm.unsupported, mapped: norm.mapped
    };
    const layout = chooseLayout(norm.paras, REGIONS[sc.deco]);
    buildStrokes(C, sc, layout);
    buildRaw(C);
    retime(C, sc);
    C.lines = layout.lines.length;
    C.count = norm.paras.join('').replace(/ /g, '').length;
    return { C: C, norm: norm };
  }

  function disposeCompiled(id) {
    const C = compiled.get(id);
    if (C && C.g.parentNode) C.g.parentNode.removeChild(C.g);
    compiled.delete(id);
    if (shownId === id) shownId = null;
  }

  function recolorScene(sc) {
    const C = compiled.get(sc.id);
    if (!C) return;
    C.strokes.forEach(function (s) {
      s.el.setAttribute('stroke', s.deco ? underlineColor(sc.ink) : sc.ink);
      s.sh.setAttribute('stroke', shadowColor(sc.bg));
    });
  }

  // Bina semula laluan jika teks atau hiasan berubah. Mengembalikan 'ok', 'sama' atau 'tidak sah'.
  function commitScene(sc) {
    const old = compiled.get(sc.id);
    if (old && old.text === sc.text && old.deco === sc.deco && old.caseMode === sc.caseMode) return 'sama';
    const res = buildCompiled(sc);
    if (!res.C) return 'tidak sah';
    disposeCompiled(sc.id);
    compiled.set(sc.id, res.C);
    return 'ok';
  }

  function commitAll() {
    let changed = false;
    scenes.forEach(function (sc) { if (commitScene(sc) === 'ok') changed = true; });
    if (changed) { recomputeProject(); renderList(); renderStrip(); }
    return changed;
  }

  function recomputeProject() {
    starts = [];
    let acc = 0;
    scenes.forEach(function (sc, i) {
      starts.push(acc);
      acc += cs(i).dur + (i < scenes.length - 1 ? TR : 0);
    });
    total = acc;
  }

  /* ---------- Warna dan tema ---------- */
  let outlineDark = null;

  function setOutline(dark) {
    if (outlineDark === dark) return;
    outlineDark = dark;
    const outline = dark ? '#f4efe2' : '#111111';
    $('#dotsCircle').setAttribute('fill', dark ? 'rgba(255,255,255,0.12)' : 'rgba(110,80,20,0.14)');
    $('#frameRect').setAttribute('stroke', outline);
    Array.prototype.forEach.call(document.querySelectorAll('.ol'), function (el) { el.setAttribute('stroke', outline); });
    $('#pencilArt').setAttribute('stroke', outline);
    creditText.setAttribute('fill', outline);
  }

  function applyPencilColors() {
    $('#pencilBody').setAttribute('fill', settings.pencil);
    $('#pencilEraser').setAttribute('fill', settings.pencil.toLowerCase() === '#e0302f' ? '#f6a7a3' : '#e0302f');
  }

  /* ---------- Lukisan garisan (stroke-dasharray / stroke-dashoffset) ---------- */
  // Nota: visibility tidak ditetapkan 'visible' secara eksplisit supaya kumpulan adegan
  // yang tersembunyi tidak dibatalkan oleh laluan anak.
  function applyDash(el, len, p) {
    if (p <= 0) { el.setAttribute('visibility', 'hidden'); return; }
    el.removeAttribute('visibility');
    if (p >= 1) {
      el.removeAttribute('stroke-dasharray');
      el.removeAttribute('stroke-dashoffset');
    } else {
      el.setAttribute('stroke-dasharray', len + ' ' + len);
      el.setAttribute('stroke-dashoffset', (len * (1 - p)).toFixed(2));
    }
  }

  function setStroke(s, p) {
    if (p === s.p) return;
    s.p = p;
    applyDash(s.el, s.len, p);
    applyDash(s.sh, s.len, p);
  }

  /* ---------- Pensel ---------- */
  function updatePencil(C, t) {
    const T = C.T;
    let x = 0, y = 0, lift = 0, ang = BASE_ANGLE, show = true;

    if (t < T.enterEnd) {
      const u = t / T.enterEnd, e = easeOutCubic(u), p0 = C.strokes[0].start;
      x = lerp(840, p0.x, e);
      y = p0.y - 90 * (1 - e);
      lift = 1 - smooth(0.45, 1, u);
      ang = BASE_ANGLE + 16 * (1 - e);
    } else if (t < T.writeEnd) {
      let seg = C.timeline[C.timeline.length - 1];
      for (let i = 0; i < C.timeline.length; i++) {
        if (t < C.timeline[i].t1) { seg = C.timeline[i]; break; }
      }
      const u = clamp((t - seg.t0) / (seg.t1 - seg.t0));
      if (seg.kind === 'draw') {
        const p = pointAt(seg.s, drawEase(u) * seg.s.len);
        x = p.x; y = p.y;
      } else {
        const e = easeInOutCubic(u);
        x = lerp(seg.a.x, seg.b.x, e);
        y = lerp(seg.a.y, seg.b.y, e) - Math.sin(Math.PI * u) * Math.min(24, seg.dist * 0.18);
        lift = Math.pow(Math.sin(Math.PI * u), 0.6) * clamp(seg.dist / 90, 0.3, 1);
      }
    } else if (t < T.exitEnd) {
      const u = (t - T.writeEnd) / (T.exitEnd - T.writeEnd), end = C.strokes[C.strokes.length - 1].end;
      x = lerp(end.x, 860, easeInCubic(u));
      y = end.y - 70 * easeOutCubic(u);
      lift = smooth(0, 0.25, u);
      ang = BASE_ANGLE + 12 * u;
    } else {
      show = false;
    }

    const vis = show ? 'visible' : 'hidden';
    setA(pencil, 'visibility', vis);
    setA(pencilShadow, 'visibility', vis);
    if (!show) return;

    // Condongkan pensel ke tengah apabila hampir tepi kanan supaya kekal dalam bingkai
    ang -= 40 * smooth(330, 500, x);

    // Gerakan kecil: putaran di sekitar hujung pensel, jadi hujung kekal tepat pada laluan
    const wob = (1 - lift) * (1.6 * Math.sin(t * 6.3) + 0.8 * Math.sin(t * 14.1 + 1.3)) + lift * 2.2 * Math.sin(t * 4.2 + 2);
    const a = ang + wob;
    const px = x + lift * 9, py = y - lift * 16;
    pencil.setAttribute('transform',
      'translate(' + px.toFixed(2) + ' ' + py.toFixed(2) + ') rotate(' + a.toFixed(2) + ') scale(' + PENCIL_SCALE + ')');

    const sdx = 0.62, sdy = 0.2 + 0.012 * wob;
    const wx = -sdy, wy = sdx, wl = Math.hypot(wx, wy);
    const m = [
      (wx / wl) * PENCIL_SCALE, (wy / wl) * PENCIL_SCALE,
      -sdx * PENCIL_SCALE, -sdy * PENCIL_SCALE,
      x + 3 + lift * 5, y + 5 + lift * 8
    ];
    pencilShadow.setAttribute('transform', 'matrix(' + m.map(function (n) { return n.toFixed(4); }).join(' ') + ')');
    pencilShadow.setAttribute('opacity', (1 - 0.35 * lift).toFixed(2));
  }

  /* ---------- Ikon buku, bintang dan kilauan ---------- */
  const bookLines = Array.prototype.slice.call(bookEl.querySelectorAll('.page-line')).map(function (el) {
    return { el: el, len: el.getTotalLength() };
  });
  const sparks = Array.prototype.slice.call(document.querySelectorAll('.spark')).map(function (g) {
    return { g: g, x: parseFloat(g.dataset.x), y: parseFloat(g.dataset.y) };
  });

  function popItem(g, x, y, rot, t, t0, dur, lines) {
    const u = clamp((t - t0) / dur);
    if (!(u > 0)) {
      setA(g, 'visibility', 'hidden');
      if (lines) lines.forEach(function (ln) { applyDash(ln.el, ln.len, 0); });
      return;
    }
    setA(g, 'visibility', 'visible');
    const s = easeOutBack(u);
    const wig = (1 - u) * 16 * Math.cos(u * 11);
    const float = 3 * smooth(0, 0.5, t - (t0 + dur)) * Math.sin((t - t0) * 3.4 + x);
    g.setAttribute('transform',
      'translate(' + x + ' ' + (y + float).toFixed(2) + ') rotate(' + (rot + wig).toFixed(2) + ') scale(' + s.toFixed(3) + ')');
    if (lines) {
      lines.forEach(function (ln, i) {
        applyDash(ln.el, ln.len, clamp((u - 0.35 - i * 0.05) / 0.5));
      });
    }
  }

  function updateIcons(C, t) {
    popItem(bookEl, 185, 765, -6, t, C.iconT.book, 0.8, bookLines);
    popItem(starEl, 375, 765, -12, t, C.iconT.star, 0.8, null);
    sparks.forEach(function (sp, i) { popItem(sp.g, sp.x, sp.y, 0, t, C.iconT.spark + i * 0.12, 0.5, null); });
  }

  /* ---------- Cari kedudukan dalam masa projek ---------- */
  function locate(t) {
    const n = scenes.length;
    for (let i = 0; i < n; i++) {
      const d = cs(i).dur, s0 = starts[i];
      if (t < s0 + d) return { i: i, local: Math.max(0, t - s0), tr: -1 };
      if (i < n - 1 && t < s0 + d + TR) return { i: i, local: d, tr: (t - s0 - d) / TR };
    }
    return { i: n - 1, local: cs(n - 1).dur, tr: -1 };
  }

  let shownId = null;
  function showOnly(id) {
    if (shownId === id) return;
    shownId = id;
    compiled.forEach(function (C) { C.g.setAttribute('visibility', C.id === id ? 'visible' : 'hidden'); });
  }

  /* ---------- Render satu bingkai pada masa projek t ---------- */
  function render(t) {
    const loc = locate(t);
    const sc = scenes[loc.i], C = cs(loc.i);

    showOnly(C.id);
    for (let i = 0; i < C.timeline.length; i++) {
      const r = C.timeline[i];
      if (r.kind !== 'draw') continue;
      const p = loc.local <= r.t0 ? 0 : (loc.local >= r.t1 ? 1 : drawEase((loc.local - r.t0) / (r.t1 - r.t0)));
      setStroke(r.s, p);
    }
    updatePencil(C, loc.local);
    updateIcons(C, loc.local);

    // Peralihan fade 0.5 saat: adegan semasa pudar, latar bertukar ke latar adegan berikutnya
    const inTr = loc.tr > 0 && state.mode === 'all' && loc.i < scenes.length - 1;
    let dark;
    setA(bgA, 'fill', sc.bg);
    if (inTr) {
      const u = smooth(0, 1, loc.tr), nx = scenes[loc.i + 1];
      setA(bgB, 'fill', nx.bg);
      setA(bgB, 'opacity', u.toFixed(3));
      setA(sceneLayer, 'opacity', (1 - u).toFixed(3));
      dark = luminance(u > 0.5 ? nx.bg : sc.bg) < 0.45;
    } else {
      setA(bgB, 'opacity', '0');
      setA(sceneLayer, 'opacity', '1');
      dark = luminance(sc.bg) < 0.45;
    }
    setOutline(dark);
    if (stageEl.__bg !== sc.bg) { stageEl.__bg = sc.bg; stageEl.style.background = sc.bg; }
  }

  /* ---------- Antara muka: senarai, editor, jalur masa ---------- */
  let nowIdx = -1;

  function renderList() {
    sceneList.textContent = '';
    scenes.forEach(function (sc, i) {
      const li = document.createElement('li');
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'scene-item';
      b.dataset.i = String(i);
      b.setAttribute('aria-current', String(i === state.sel));
      const num = document.createElement('span');
      num.className = 'num';
      num.textContent = String(i + 1);
      num.style.setProperty('--c', sc.bg);
      num.style.setProperty('--tc', luminance(sc.bg) < 0.45 ? '#f4efe2' : '#111');
      const title = document.createElement('span');
      title.className = 'title';
      title.textContent = sc.text.replace(/\s+/g, ' ').trim() || '(kosong)';
      const dur = document.createElement('span');
      dur.className = 'dur';
      dur.textContent = fmt(cs(i).dur) + ' s';
      b.appendChild(num); b.appendChild(title); b.appendChild(dur);
      li.appendChild(b);
      sceneList.appendChild(li);
    });
    sceneCount.textContent = scenes.length + ' / ' + MAX_SCENES;
    btnAdd.disabled = scenes.length >= MAX_SCENES;
    btnDup.disabled = scenes.length >= MAX_SCENES;
    btnDel.disabled = scenes.length <= 1;
    btnUp.disabled = state.sel <= 0;
    btnDown.disabled = state.sel >= scenes.length - 1;
    nowIdx = -1;
    markNow();
  }

  function renderStrip() {
    strip.textContent = '';
    const idxs = state.mode === 'scene' ? [state.sel] : scenes.map(function (_, i) { return i; });
    idxs.forEach(function (i) {
      const d = document.createElement('div');
      d.className = 'seg-scene';
      d.dataset.i = String(i);
      const extra = state.mode === 'all' && i < scenes.length - 1 ? TR : 0;
      d.style.flexGrow = String(cs(i).dur + extra);
      d.style.background = scenes[i].bg;
      d.style.color = luminance(scenes[i].bg) < 0.45 ? '#f4efe2' : '#111';
      d.textContent = String(i + 1);
      strip.appendChild(d);
    });
    nowIdx = -1;
    markNow();
  }

  function markNow() {
    const idx = locate(state.t).i;
    if (idx === nowIdx) return;
    nowIdx = idx;
    Array.prototype.forEach.call(sceneList.querySelectorAll('.scene-item'), function (b) {
      b.classList.toggle('is-now', parseInt(b.dataset.i, 10) === idx);
    });
    Array.prototype.forEach.call(strip.querySelectorAll('.seg-scene'), function (d) {
      d.classList.toggle('is-now', parseInt(d.dataset.i, 10) === idx);
    });
  }

  function loadEditor() {
    const sc = scenes[state.sel];
    editorTitle.textContent = 'Adegan ' + (state.sel + 1);
    textInput.value = sc.text;
    charCount.textContent = sc.text.length + '/' + MAX_CHARS;
    sceneSpeed.value = String(sc.speed);
    sceneSpeedText.textContent = sc.speed.toFixed(2) + '\u00d7';
    scenePause.value = String(sc.pause);
    scenePauseText.textContent = sc.pause.toFixed(1) + ' s';
    sceneDeco.value = sc.deco;
    refreshSwatches('bg'); refreshSwatches('ink'); refreshSwatches('pencil');
    sceneCase.value = sc.caseMode;
    updateContrast();
    updateCharWarn();
  }

  function range() {
    if (state.mode === 'scene') return [starts[state.sel], starts[state.sel] + cs(state.sel).dur];
    return [0, total];
  }

  function updateUI() {
    const loc = locate(state.t);
    const n = scenes.length;
    const rg = range();
    infoScene.textContent = 'Adegan semasa: ' + (loc.i + 1) + ' daripada ' + n;
    stageCaption.textContent = 'Adegan ' + (loc.i + 1) + ' daripada ' + n;
    if (state.mode === 'scene') {
      infoTime.textContent = 'Masa adegan: ' + fmt(state.t - rg[0]) + ' / ' + fmt(rg[1] - rg[0]) + ' s';
    } else {
      infoTime.textContent = 'Masa projek: ' + fmt(state.t) + ' / ' + fmt(total) + ' s';
    }
    infoTotal.textContent = 'Jumlah tempoh projek: ' + fmt(total) + ' s';
    const span = Math.max(1e-6, rg[1] - rg[0]);
    scrub.value = String(Math.round(clamp((state.t - rg[0]) / span) * 1000));
    btnPlay.classList.toggle('is-active', state.playing);
    btnPause.classList.toggle('is-active', !state.playing && !state.showcase && state.t > rg[0] && state.t < rg[1]);
    stateText.textContent = state.playing ? 'Sedang dimainkan.'
      : (state.showcase ? 'Pratonton adegan terpilih. Tekan Main untuk menonton.'
      : (state.t >= rg[1] - 1e-6 ? 'Tamat.' : (state.t > rg[0] ? 'Dijeda.' : 'Sedia.')));
    modeAll.setAttribute('aria-pressed', String(state.mode === 'all'));
    modeScene.setAttribute('aria-pressed', String(state.mode === 'scene'));
    markNow();
  }

  function say(text, warn) {
    msgEl.textContent = text;
    msgEl.classList.toggle('warn', !!warn);
  }

  function projSay(text, warn) {
    projMsg.textContent = text;
    projMsg.classList.toggle('warn', !!warn);
  }

  /* ---------- Kawalan main (satu gelung rAF, satu masa projek) ---------- */
  function schedule() {
    cancelAnimationFrame(state.raf);
    state.raf = requestAnimationFrame(frame);
  }

  function frame(now) {
    if (!state.playing) return;
    const dt = Math.min(0.1, Math.max(0, (now - state.last) / 1000));
    state.last = now;
    const rg = range();
    state.t = Math.min(rg[1], state.t + dt * state.rate);
    if (state.t >= rg[1]) state.playing = false;
    render(state.t);
    updateUI();
    if (state.playing) schedule();
  }

  function play() {
    state.touched = true;
    commitAll();
    if (state.playing) return;
    const rg = range();
    if (state.showcase) {
      state.t = rg[0];
      state.showcase = false;
    } else if (state.t >= rg[1] - 1e-6 || state.t < rg[0]) {
      state.t = rg[0];
    }
    state.playing = true;
    state.last = performance.now();
    render(state.t);
    schedule();
    updateUI();
  }

  function pause() {
    state.touched = true;
    state.playing = false;
    cancelAnimationFrame(state.raf);
    updateUI();
  }

  function seek(t) {
    const rg = range();
    state.t = clamp(t, rg[0], rg[1]);
    render(state.t);
    updateUI();
  }

  // Tunjuk adegan terpilih dalam keadaan siap (semua tulisan kelihatan)
  function showcaseSelected() {
    pause();
    const C = cs(state.sel);
    state.t = starts[state.sel] + C.contentEnd;
    state.showcase = true;
    render(state.t);
    updateUI();
  }

  function replay() {
    state.touched = true;
    commitAll();
    cancelAnimationFrame(state.raf);
    state.playing = false;
    state.showcase = false;
    state.t = range()[0];
    render(state.t);
    state.playing = true;
    state.last = performance.now();
    schedule();
    updateUI();
  }

  // Selepas perubahan kelajuan atau jeda: kekalkan kedudukan dalam adegan yang sama
  function retimeKeep(sc) {
    const before = locate(state.t);
    const id = scenes[before.i].id;
    const wasTr = before.tr > 0;
    const trFrac = before.tr;
    retime(compiled.get(sc.id), sc);
    recomputeProject();
    const i = scenes.findIndex(function (s) { return s.id === id; });
    const d = cs(i).dur;
    state.t = starts[i] + (wasTr ? d + trFrac * TR : Math.min(before.local, d));
    const rg = range();
    state.t = clamp(state.t, rg[0], rg[1]);
    render(state.t);
    renderList();
    renderStrip();
    updateUI();
  }

  /* ---------- Operasi adegan ---------- */
  function newScene(partial) {
    return Object.assign({
      id: uid(), text: 'Adegan baharu', bg: '#fbf3dc', ink: '#111111', speed: 1, pause: 1.5, deco: 'underline', caseMode: 'asal'
    }, partial || {});
  }

  function afterStructure() {
    recomputeProject();
    renderList();
    renderStrip();
    loadEditor();
    persist();
    showcaseSelected();
  }

  function selectScene(i) {
    if (i === state.sel) { showcaseSelected(); return; }
    commitAll();
    state.sel = clamp(i, 0, scenes.length - 1);
    btnUndo.hidden = true;
    renderList();
    renderStrip();
    loadEditor();
    say('', false);
    showcaseSelected();
  }

  function addScene() {
    if (scenes.length >= MAX_SCENES) { say('Had maksimum ' + MAX_SCENES + ' adegan telah dicapai.', true); return; }
    commitAll();
    const sc = newScene();
    scenes.push(sc);
    commitScene(sc);
    state.sel = scenes.length - 1;
    btnUndo.hidden = true;
    say('Adegan baharu ditambah. Taip teks anda, kemudian klik Jana Animasi.', false);
    afterStructure();
  }

  function duplicateScene() {
    if (scenes.length >= MAX_SCENES) { say('Had maksimum ' + MAX_SCENES + ' adegan telah dicapai.', true); return; }
    commitAll();
    const src = scenes[state.sel];
    const copy = newScene({ text: src.text, bg: src.bg, ink: src.ink, speed: src.speed, pause: src.pause, deco: src.deco, caseMode: src.caseMode });
    scenes.splice(state.sel + 1, 0, copy);
    commitScene(copy);
    state.sel += 1;
    btnUndo.hidden = true;
    say('Adegan diduplikasi.', false);
    afterStructure();
  }

  function deleteScene() {
    if (scenes.length <= 1) { say('Projek mesti mempunyai sekurang-kurangnya satu adegan.', true); return; }
    commitAll();
    const sc = scenes[state.sel];
    lastDeleted = { sc: Object.assign({}, sc), index: state.sel };
    disposeCompiled(sc.id);
    scenes.splice(state.sel, 1);
    state.sel = clamp(state.sel, 0, scenes.length - 1);
    btnUndo.hidden = false;
    say('Adegan dipadam.', false);
    afterStructure();
  }

  function undoDelete() {
    if (!lastDeleted || scenes.length >= MAX_SCENES) { btnUndo.hidden = true; return; }
    const sc = lastDeleted.sc;
    scenes.splice(clamp(lastDeleted.index, 0, scenes.length), 0, sc);
    commitScene(sc);
    state.sel = scenes.indexOf(sc);
    lastDeleted = null;
    btnUndo.hidden = true;
    say('Adegan dipulihkan.', false);
    afterStructure();
  }

  function moveScene(dir) {
    const j = state.sel + dir;
    if (j < 0 || j >= scenes.length) return;
    commitAll();
    const tmp = scenes[state.sel];
    scenes[state.sel] = scenes[j];
    scenes[j] = tmp;
    state.sel = j;
    btnUndo.hidden = true;
    say('Adegan dialihkan ke kedudukan ' + (j + 1) + '.', false);
    afterStructure();
  }

  /* ---------- Teks adegan: jana ---------- */
  function generateSelected() {
    const sc = scenes[state.sel];
    const norm = normalizeText(sc.text, sc.caseMode);
    if (!norm.paras.length) {
      say(norm.unsupported.length
        ? 'Tiada aksara yang disokong dalam teks ini. Lihat senarai aksara yang disokong di bawah.'
        : 'Sila taip teks dahulu sebelum menjana animasi.', true);
      return;
    }
    cancelAnimationFrame(state.raf);
    state.playing = false;
    // Paksa bina semula supaya animasi bermula dari awal dengan teks terkini
    const old = compiled.get(sc.id);
    if (old) old.text = null;
    commitScene(sc);
    commitAll();
    recomputeProject();
    renderList();
    renderStrip();
    persist();
    const C = cs(state.sel);
    let note = 'Animasi dijana: ' + C.lines + ' baris, ' + C.count + ' aksara.';
    const wt = warnText(C);
    if (wt) note += ' ' + wt;
    say(note, !!wt);
    // Mainkan dari awal adegan ini
    state.showcase = false;
    state.touched = true;
    state.t = starts[state.sel];
    render(state.t);
    state.playing = true;
    state.last = performance.now();
    schedule();
    updateUI();
  }

  /* ---------- Warna ---------- */
  function getColor(kind) { return kind === 'pencil' ? settings.pencil : scenes[state.sel][kind]; }

  function refreshSwatches(kind) {
    const host = $('#sw-' + kind);
    if (!host.firstChild) return;
    const cur = getColor(kind).toLowerCase();
    let preset = false;
    Array.prototype.forEach.call(host.querySelectorAll('button.swatch'), function (b) {
      const on = b.dataset.hex.toLowerCase() === cur;
      if (on) preset = true;
      b.setAttribute('aria-pressed', String(on));
    });
    const custom = host.querySelector('.custom');
    custom.classList.toggle('is-selected', !preset);
    if (!preset) custom.style.setProperty('--c', getColor(kind));
    custom.querySelector('input').value = getColor(kind);
    const hx = host.querySelector('input.hex');
    if (hx) { hx.value = getColor(kind).toUpperCase(); hx.classList.remove('bad'); hx.removeAttribute('aria-invalid'); }
  }

  function setColor(kind, hex) {
    if (kind === 'pencil') {
      settings.pencil = hex;
      applyPencilColors();
    } else {
      const sc = scenes[state.sel];
      sc[kind] = hex;
      recolorScene(sc);
      renderList();
      renderStrip();
    }
    refreshSwatches(kind);
    render(state.t);
    persist();
    updateContrast();
  }

  function buildSwatches(kind) {
    const host = $('#sw-' + kind);
    PALETTES[kind].forEach(function (item) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'swatch';
      b.style.setProperty('--c', item[1]);
      b.setAttribute('aria-label', item[0]);
      b.title = item[0];
      b.dataset.hex = item[1];
      b.addEventListener('click', function () { setColor(kind, item[1]); });
      host.appendChild(b);
    });
    const lab = document.createElement('label');
    lab.className = 'swatch custom';
    lab.title = 'Warna lain';
    const inp = document.createElement('input');
    inp.type = 'color';
    inp.value = '#888888';
    inp.setAttribute('aria-label', 'Warna ' + PALETTE_NAMES[kind] + ' lain');
    inp.addEventListener('input', function () { setColor(kind, inp.value); });
    lab.appendChild(inp);
    host.appendChild(lab);
    // Input kod HEX (#RRGGBB atau RGB)
    const hx = document.createElement('input');
    hx.type = 'text'; hx.className = 'hex'; hx.maxLength = 7; hx.spellcheck = false; hx.autocomplete = 'off';
    hx.placeholder = '#RRGGBB';
    hx.setAttribute('aria-label', 'Kod HEX warna ' + PALETTE_NAMES[kind]);
    hx.addEventListener('change', function () {
      const v = parseHex(hx.value);
      if (!v) {
        hx.classList.add('bad'); hx.setAttribute('aria-invalid', 'true');
        say('Kod HEX tidak sah. Gunakan format #RRGGBB, contohnya #14284B. Warna tidak diubah.', true);
        return;
      }
      setColor(kind, v);
    });
    host.appendChild(hx);
  }

  /* ---------- Projek: serialisasi, import, eksport ---------- */
  function serialize() {
    return JSON.stringify({
      app: 'PencilMotion EDU',
      version: '1E',
      pencil: settings.pencil,
      credit: settings.credit,
      scenes: scenes.map(function (s) {
        return { text: s.text, bg: s.bg, ink: s.ink, speed: s.speed, pause: s.pause, deco: s.deco, caseMode: s.caseMode };
      })
    }, null, 2);
  }

  // Sahkan dan bersihkan data projek. Membuang ralat dalam Bahasa Malaysia jika tidak sah.
  function parseProject(raw) {
    let obj;
    try { obj = typeof raw === 'string' ? JSON.parse(raw) : raw; }
    catch (e) { throw new Error('Fail bukan JSON yang sah.'); }
    if (!obj || typeof obj !== 'object' || !Array.isArray(obj.scenes) || obj.scenes.length === 0) {
      throw new Error('Fail ini bukan projek PencilMotion EDU (senarai adegan tidak dijumpai).');
    }
    const notes = [];
    let list = obj.scenes;
    if (list.length > MAX_SCENES) {
      list = list.slice(0, MAX_SCENES);
      notes.push('Hanya ' + MAX_SCENES + ' adegan pertama diimport.');
    }
    const out = list.map(function (s) {
      s = s && typeof s === 'object' ? s : {};
      let text = typeof s.text === 'string' ? s.text.slice(0, MAX_CHARS) : '';
      if (!normalizeText(text).paras.length) { text = 'ADEGAN'; notes.push('Satu adegan tanpa teks sah diganti dengan "ADEGAN".'); }
      const speed = Number(s.speed), pause = Number(s.pause);
      return {
        text: text,
        bg: isHex(s.bg) ? s.bg.toLowerCase() : '#fbf3dc',
        ink: isHex(s.ink) ? s.ink.toLowerCase() : '#111111',
        speed: isFinite(speed) ? clamp(Math.round(speed * 20) / 20, 0.25, 2) : 1,
        pause: isFinite(pause) ? clamp(Math.round(pause * 2) / 2, 0, 5) : 1.5,
        deco: DECOS.indexOf(s.deco) >= 0 ? s.deco : 'underline',
        // Fail lama (sebelum Fasa 1E) sentiasa dilukis dalam huruf besar; kekalkan rupa asalnya
        caseMode: CASES.indexOf(s.caseMode) >= 0 ? s.caseMode : 'besar'
      };
    });
    return { pencil: isHex(obj.pencil) ? obj.pencil.toLowerCase() : '#1f5fd6', scenes: out, notes: notes, credit: obj.credit !== false };
  }

  function loadProject(p) {
    if (scenes.length) pause(); else state.playing = false;
    compiled.forEach(function (C) { if (C.g.parentNode) C.g.parentNode.removeChild(C.g); });
    compiled.clear();
    shownId = null;
    scenes = p.scenes.map(function (s) { return Object.assign({ id: uid() }, s); });
    scenes.forEach(function (sc) {
      if (commitScene(sc) !== 'ok') { sc.text = 'ADEGAN'; commitScene(sc); }
    });
    settings.pencil = p.pencil;
    settings.credit = p.credit !== false;
    applyPencilColors();
    applyCredit();
    state.sel = 0;
    state.t = 0;
    lastDeleted = null;
    btnUndo.hidden = true;
    afterStructure();
  }

  function persist() {
    try { localStorage.setItem(STORE_KEY, serialize()); } catch (e) { /* storan tidak tersedia */ }
  }

  function readStored() {
    try {
      const raw = localStorage.getItem(STORE_KEY) || localStorage.getItem(LEGACY_KEY);
      return raw ? parseProject(raw) : null;
    } catch (e) { return null; }
  }

  async function downloadProject() {
    const data = serialize();
    const name = 'projek-pencilmotion-edu.json';
    try {
      if (window.claude && typeof window.claude.use === 'function') {
        const dl = await window.claude.use('downloads');
        if (dl) {
          await dl.save({ filename: name, data: data });
          projSay('Fail projek dihantar untuk disimpan. Sahkan dalam dialog yang dipaparkan.', false);
          return;
        }
      }
    } catch (e) {
      if (e && e.code === 'declined') { projSay('Muat turun dibatalkan.', false); return; }
      projSay('Muat turun tidak berjaya. Gunakan Salin JSON sebagai gantinya.', true);
      return;
    }
    try {
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      projSay('Fail projek dimuat turun. Jika tiada fail, gunakan Salin JSON.', false);
    } catch (e) {
      projSay('Muat turun disekat dalam persekitaran ini. Gunakan Salin JSON sebagai gantinya.', true);
    }
  }

  async function copyProject() {
    const data = serialize();
    try {
      await navigator.clipboard.writeText(data);
      projSay('JSON projek disalin ke papan klip.', false);
    } catch (e) {
      importText.value = data;
      importText.focus();
      importText.select();
      projSay('Penyalinan automatik disekat. JSON dipaparkan dalam kotak di bawah; tekan Ctrl+C untuk menyalinnya.', true);
    }
  }

  function importFrom(raw) {
    try {
      const p = parseProject(raw);
      loadProject(p);
      projSay('Projek diimport: ' + p.scenes.length + ' adegan.' + (p.notes.length ? ' ' + p.notes.join(' ') : ''), p.notes.length > 0);
      return true;
    } catch (e) {
      projSay(e.message || 'Import gagal.', true);
      return false;
    }
  }

  /* ---------- Pendengar acara ---------- */
  sceneList.addEventListener('click', function (e) {
    const b = e.target instanceof Element ? e.target.closest('button[data-i]') : null;
    if (b) selectScene(parseInt(b.dataset.i, 10));
  });
  btnAdd.addEventListener('click', addScene);
  btnDup.addEventListener('click', duplicateScene);
  btnDel.addEventListener('click', deleteScene);
  btnUp.addEventListener('click', function () { moveScene(-1); });
  btnDown.addEventListener('click', function () { moveScene(1); });
  btnUndo.addEventListener('click', undoDelete);

  textInput.addEventListener('input', function () {
    scenes[state.sel].text = textInput.value;
    const ti = sceneList.querySelectorAll('.scene-item .title')[state.sel];
    if (ti) ti.textContent = textInput.value.replace(/\s+/g, ' ').trim() || '(kosong)';
    charCount.textContent = textInput.value.length + '/' + MAX_CHARS;
    updateCharWarn();
    persist();
  });
  textInput.addEventListener('change', function () {
    const r = commitScene(scenes[state.sel]);
    if (r === 'ok') { recomputeProject(); renderList(); renderStrip(); showcaseSelected(); }
    else if (r === 'tidak sah') say('Teks belum sah. Taip sekurang-kurangnya satu aksara yang disokong.', true);
  });
  textInput.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); generateSelected(); }
  });
  btnGenerate.addEventListener('click', generateSelected);

  sceneSpeed.addEventListener('input', function () {
    const sc = scenes[state.sel];
    sc.speed = parseFloat(sceneSpeed.value);
    sceneSpeedText.textContent = sc.speed.toFixed(2) + '\u00d7';
    retimeKeep(sc);
    persist();
  });
  scenePause.addEventListener('input', function () {
    const sc = scenes[state.sel];
    sc.pause = parseFloat(scenePause.value);
    scenePauseText.textContent = sc.pause.toFixed(1) + ' s';
    retimeKeep(sc);
    persist();
  });
  sceneDeco.addEventListener('change', function () {
    const sc = scenes[state.sel];
    sc.deco = sceneDeco.value;
    if (commitScene(sc) === 'ok') { recomputeProject(); renderList(); renderStrip(); persist(); showcaseSelected(); }
  });

  function setMode(m) {
    if (state.mode === m) return;
    commitAll();
    pause();
    state.mode = m;
    renderStrip();
    showcaseSelected();
  }
  modeAll.addEventListener('click', function () { setMode('all'); });
  modeScene.addEventListener('click', function () { setMode('scene'); });

  btnPlay.addEventListener('click', play);
  btnPause.addEventListener('click', pause);
  btnReplay.addEventListener('click', replay);

  rate.addEventListener('input', function () {
    state.rate = parseFloat(rate.value);
    rateText.textContent = state.rate.toFixed(2) + '\u00d7';
  });

  scrub.addEventListener('input', function () {
    // Baca nilai peluncur SEBELUM pause(), kerana pause() mengemas kini peluncur ke masa semasa
    const v = parseFloat(scrub.value);
    pause();
    commitAll();
    state.showcase = false;
    const rg = range();
    state.t = rg[0] + (v / 1000) * (rg[1] - rg[0]);
    render(state.t);
    updateUI();
  });

  btnDownload.addEventListener('click', downloadProject);
  btnCopy.addEventListener('click', copyProject);
  btnSample.addEventListener('click', function () {
    loadProject(parseProject(SAMPLE));
    projSay('Projek contoh dimuatkan.', false);
  });
  btnImportText.addEventListener('click', function () {
    if (!importText.value.trim()) { projSay('Tampal JSON projek dahulu.', true); return; }
    importFrom(importText.value);
  });
  fileImport.addEventListener('change', function () {
    const f = fileImport.files && fileImport.files[0];
    if (!f) return;
    const rd = new FileReader();
    rd.onload = function () { importFrom(String(rd.result)); fileImport.value = ''; };
    rd.onerror = function () { projSay('Fail tidak dapat dibaca.', true); fileImport.value = ''; };
    rd.readAsText(f);
  });

  document.addEventListener('keydown', function (e) {
    if (exporting) return;
    if (e.target instanceof Element && e.target.closest('button, input, textarea, select, summary, label')) return;
    if (e.code === 'Space') { e.preventDefault(); if (state.playing) pause(); else play(); }
    else if (e.key === 'r' || e.key === 'R') replay();
  });

  /* =====================================================================
     FASA 1D: EKSPORT VIDEO (rakaman masa nyata, tanpa pelayan)

     Aliran: render(t) mengemas kini SVG pratonton -> SVG diserialisasi ->
     dimuat sebagai imej -> dilukis ke Canvas -> canvas.captureStream() ->
     MediaRecorder. Masa animasi diambil daripada jam dinding
     (performance.now), bukan daripada kiraan bingkai, jadi kelajuan dan
     panjang video kekal tepat walaupun sesetengah bingkai terlepas.
     Eksport tidak mengubah data projek; keadaan pratonton dipulihkan.
     ===================================================================== */
  const EXPORT_FPS = 30;
  const EXPORT_TAIL = 0.4;   // saat bingkai akhir ditahan supaya tidak terpotong
  const RES = {
    '540': { w: 540, h: 960, bps: 4000000 },
    '720': { w: 720, h: 1280, bps: 8000000 },
    '1080': { w: 1080, h: 1920, bps: 14000000 }
  };
  // VP8 diutamakan kerana lebih ringan untuk rakaman masa nyata pada komputer biasa
  const MIME_CANDIDATES = {
    webm: ['video/webm;codecs=vp8', 'video/webm;codecs=vp9', 'video/webm'],
    mp4: ['video/mp4;codecs=avc1.42E01E', 'video/mp4;codecs=avc1', 'video/mp4']
  };
  const VIDEO_BASENAME = 'PencilMotion-EDU-Video';

  const expRes = $('#expRes');
  const expFormats = $('#expFormats');
  const expNote = $('#expNote');
  const btnExport = $('#btnExport');
  const btnCancelExport = $('#btnCancelExport');
  const btnDownloadVideo = $('#btnDownloadVideo');
  const expProgress = $('#expProgress');
  const expStatus = $('#expStatus');
  const expCanvas = $('#expCanvas');
  const expVideo = $('#expVideo');
  const expInfo = $('#expInfo');
  const canvasSvg = $('#canvas');

  let exporting = false;
  const ex = { cancel: false, reason: '', stream: null, recorder: null, url: null, result: null };

  function detectSupport() {
    const s = { ok: false, reason: '', webm: null, mp4: null };
    if (typeof window.MediaRecorder !== 'function') {
      s.reason = 'Pelayar ini tidak menyediakan MediaRecorder, jadi rakaman video tidak dapat dilakukan.';
      return s;
    }
    if (typeof HTMLCanvasElement === 'undefined' || typeof HTMLCanvasElement.prototype.captureStream !== 'function') {
      s.reason = 'Pelayar ini tidak menyokong canvas.captureStream(), jadi rakaman video tidak dapat dilakukan.';
      return s;
    }
    const pick = function (list) {
      for (let i = 0; i < list.length; i++) {
        try { if (MediaRecorder.isTypeSupported(list[i])) return list[i]; } catch (e) { /* abaikan */ }
      }
      return null;
    };
    s.webm = pick(MIME_CANDIDATES.webm);
    s.mp4 = pick(MIME_CANDIDATES.mp4);
    if (!s.webm && !s.mp4) {
      s.reason = 'Pelayar ini tidak menyokong format video WebM atau MP4 untuk rakaman.';
      return s;
    }
    s.ok = true;
    return s;
  }

  let support = detectSupport();

  function expSay(text, warn) {
    expStatus.textContent = text;
    expStatus.classList.toggle('warn', !!warn);
  }

  function selectedFormat() {
    const r = expFormats.querySelector('input[name="expFmt"]:checked');
    return r ? r.value : null;
  }

  // Pilihan format dibina daripada sokongan sebenar pelayar. MP4 tidak dipaparkan jika tidak disokong.
  function initExportUI() {
    support = detectSupport();
    expFormats.textContent = '';
    const addOpt = function (value, label, enabled, checked) {
      const lab = document.createElement('label');
      lab.className = 'fmt-opt';
      const inp = document.createElement('input');
      inp.type = 'radio'; inp.name = 'expFmt'; inp.value = value;
      inp.disabled = !enabled; inp.checked = checked;
      const span = document.createElement('span');
      span.textContent = label;
      lab.appendChild(inp); lab.appendChild(span);
      expFormats.appendChild(lab);
    };
    addOpt('webm', support.webm ? 'WebM (utama)' : 'WebM (tidak disokong pelayar ini)', !!support.webm, !!support.webm);
    if (support.mp4) addOpt('mp4', 'MP4 (disokong oleh pelayar ini)', true, !support.webm);

    if (!support.ok) {
      expNote.textContent = support.reason + ' Muat turun fail HTML kendiri daripada Claude dan bukanya dalam Chrome terkini untuk mengeksport video.';
      expNote.classList.add('warn');
      btnExport.disabled = true;
      expSay('Eksport video tidak tersedia dalam pelayar ini.', true);
    } else {
      expNote.classList.remove('warn');
      expNote.textContent = support.mp4
        ? 'Kadar bingkai ditetapkan 30 FPS. WebM ialah format utama. MP4 ditawarkan kerana pelayar ini menyokongnya.'
        : 'Kadar bingkai ditetapkan 30 FPS. MP4 tidak ditawarkan kerana pelayar ini tidak menyokong rakaman MP4. Gunakan WebM.';
      btnExport.disabled = false;
      expSay('Sedia. Anggaran masa rakaman: ' + fmt(total + EXPORT_TAIL) + ' s (masa nyata).', false);
    }
  }

  /* ---------- SVG langsung -> teks SVG kendiri ---------- */
  const xmlSer = new XMLSerializer();
  // Hanya adegan yang kelihatan diserialisasi; adegan tersembunyi dilangkau supaya setiap bingkai ringan.
  function snapshotSVG(W, H) {
    const ser = function (el) { return xmlSer.serializeToString(el); };
    let out = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 540 960" width="' + W + '" height="' + H + '">';
    Array.prototype.forEach.call(canvasSvg.children, function (c) {
      if (c.id === 'sceneLayer') {
        out += '<g opacity="' + (c.getAttribute('opacity') || '1') + '">';
        Array.prototype.forEach.call(c.children, function (cc) {
          if (cc.id === 'sceneGroups') {
            const C = compiled.get(shownId);
            if (C) out += ser(C.g);
          } else {
            out += ser(cc);
          }
        });
        out += '</g>';
      } else {
        out += ser(c);
      }
    });
    return out + '</svg>';
  }

  const svgToUrl = (svg) => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);

  function loadImg(img, url) {
    return new Promise(function (resolve, reject) {
      img.onload = function () { resolve(); };
      img.onerror = function () { reject(new Error('Imej SVG gagal dimuatkan ke dalam canvas.')); };
      img.src = url;
    });
  }

  function nextFrame() { return new Promise(function (r) { requestAnimationFrame(r); }); }

  function hexToRgb(hex) {
    const n = parseInt(hex.slice(1), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }

  // Semakan sebelum rakaman: canvas tidak tercemar dan SVG benar-benar dirender (bukan kosong)
  function preflight(ctx, W, H, bg) {
    let px;
    try { px = ctx.getImageData(Math.round(W * 0.06), Math.round(H * 0.5), 1, 1).data; }
    catch (e) { throw new Error('Canvas disekat oleh pelayar (SecurityError) selepas melukis SVG.'); }
    const want = hexToRgb(bg);
    const diff = Math.abs(px[0] - want[0]) + Math.abs(px[1] - want[1]) + Math.abs(px[2] - want[2]);
    if (diff > 30) throw new Error('SVG tidak dirender dengan betul ke canvas (bingkai pertama kosong atau salah warna).');
  }

  // Peratus piksel yang berbeza daripada latar: bukti bahawa bingkai akhir mengandungi tulisan dan ilustrasi
  function coverage(ctx, W, H, bg) {
    const d = ctx.getImageData(0, 0, W, H).data, want = hexToRgb(bg);
    let n = 0, hit = 0;
    for (let y = 0; y < H; y += 4) {
      for (let x = 0; x < W; x += 4) {
        const i = (y * W + x) * 4;
        n++;
        if (Math.abs(d[i] - want[0]) + Math.abs(d[i + 1] - want[1]) + Math.abs(d[i + 2] - want[2]) > 60) hit++;
      }
    }
    return hit / n;
  }

  function revokeVideo() {
    if (ex.url) { URL.revokeObjectURL(ex.url); ex.url = null; }
    expVideo.removeAttribute('src');
    expVideo.hidden = true;
    expVideo.load();
    expInfo.hidden = true;
    expInfo.textContent = '';
    ex.result = null;
    btnDownloadVideo.disabled = true;
  }

  // Pengekod video pada penggunaan pertama mengambil masa memulakan diri dan menggugurkan bingkai awal.
  // Rakaman percubaan ringkas (dibuang) dijalankan dahulu supaya rakaman sebenar bermula dengan stabil.
  const warmed = {};
  async function warmUpEncoder(canvas, mime, bps, key) {
    if (warmed[key]) return;
    const stream = canvas.captureStream(EXPORT_FPS);
    let rec = null;
    try {
      const ctx = canvas.getContext('2d');
      const hold = document.createElement('canvas');
      hold.width = canvas.width; hold.height = canvas.height;
      hold.getContext('2d').drawImage(canvas, 0, 0);
      rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: bps });
      rec.ondataavailable = function () { /* dibuang */ };
      const started = new Promise(function (r) { rec.onstart = r; });
      const stopped = new Promise(function (r) { rec.onstop = r; });
      rec.start(250);
      await started;
      const end = performance.now() + 1500;
      while (performance.now() < end && !ex.cancel) {
        await nextFrame();
        ctx.drawImage(hold, 0, 0);
      }
      if (rec.state !== 'inactive') rec.stop();
      await stopped;
      // Rehat beberapa bingkai supaya pengekod selesai ditutup sebelum rakaman sebenar bermula
      for (let i = 0; i < 20 && !ex.cancel; i++) await nextFrame();
      warmed[key] = true;
    } finally {
      try { if (rec && rec.state !== 'inactive') rec.stop(); } catch (e) { /* abaikan */ }
      stream.getTracks().forEach(function (tr) { tr.stop(); });
    }
  }

  function setLocked(on) {
    Array.prototype.forEach.call(document.querySelectorAll('[data-lock]'), function (el) {
      el.inert = on;
      el.classList.toggle('is-locked', on);
    });
    btnExport.disabled = on || !support.ok;
    btnCancelExport.disabled = !on;
    expRes.disabled = on;
    optCredit.disabled = on;
    Array.prototype.forEach.call(expFormats.querySelectorAll('input'), function (i) {
      i.disabled = on || (i.value === 'webm' ? !support.webm : !support.mp4);
    });
  }

  function errorText(e) {
    const name = e && e.name ? e.name + ': ' : '';
    return 'Eksport gagal. ' + name + (e && e.message ? e.message : 'Ralat tidak diketahui.') +
      ' Cuba pilih resolusi lebih rendah, atau muat turun fail HTML kendiri dan jalankan dalam Chrome.';
  }

  function addInfo(label, value) {
    const dt = document.createElement('dt'); dt.textContent = label;
    const dd = document.createElement('dd'); dd.textContent = value;
    expInfo.appendChild(dt); expInfo.appendChild(dd);
  }

  // WebM daripada MediaRecorder tiada tempoh dalam metadata (duration = Infinity). Melompat ke hujung memaksa pelayar mengiranya.
  function fixDuration(v) {
    if (isFinite(v.duration) && v.duration > 0) return Promise.resolve(v.duration);
    return new Promise(function (resolve) {
      let finished = false;
      const finish = function () {
        if (finished) return;
        finished = true;
        v.removeEventListener('durationchange', check);
        v.removeEventListener('timeupdate', check);
        const d = v.duration;
        v.currentTime = 0;
        resolve(d);
      };
      const check = function () { if (isFinite(v.duration) && v.duration > 0) finish(); };
      v.addEventListener('durationchange', check);
      v.addEventListener('timeupdate', check);
      setTimeout(finish, 4000);   // pengaman sahaja; bukan sebahagian daripada animasi
      v.currentTime = 1e7;
    });
  }

  async function startExport() {
    if (exporting) return;
    support = detectSupport();
    if (!support.ok) { initExportUI(); return; }
    const fmtKey = selectedFormat();
    const mime = fmtKey ? support[fmtKey] : null;
    if (!mime) { expSay('Format yang dipilih tidak disokong oleh pelayar ini.', true); return; }
    const res = RES[expRes.value] || RES['720'];

    commitAll();
    pause();
    const saved = { t: state.t, mode: state.mode, showcase: state.showcase };
    const projectBefore = serialize();

    revokeVideo();
    exporting = true;
    ex.cancel = false; ex.reason = ''; ex.stream = null; ex.recorder = null;
    setLocked(true);
    expProgress.value = 0;
    expSay('Menyediakan rakaman...', false);

    const stat = { frames: 0, drawMs: 0, maxDrawMs: 0, recordedMs: 0, coverage: 0 };
    let blob = null, cancelled = false, failure = null;
    const img = new Image();

    try {
      state.mode = 'all';       // rakam keseluruhan projek, termasuk peralihan adegan
      expCanvas.width = res.w;
      expCanvas.height = res.h;
      expCanvas.hidden = false;
      const ctx = expCanvas.getContext('2d', { alpha: false });
      if (!ctx) throw new Error('Konteks canvas 2D tidak tersedia.');

      let blobMode = false;     // sandaran: gunakan URL blob jika imej data: disekat oleh dasar keselamatan halaman
      const drawFrame = async function () {
        const t0 = performance.now();
        const svg = snapshotSVG(res.w, res.h);
        let blobUrl = null;
        if (blobMode) {
          blobUrl = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
          await loadImg(img, blobUrl);
        } else {
          try {
            await loadImg(img, svgToUrl(svg));
          } catch (e) {
            if (stat.frames > 0) throw e;
            blobMode = true;
            blobUrl = URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' }));
            await loadImg(img, blobUrl);
          }
        }
        ctx.drawImage(img, 0, 0, res.w, res.h);
        if (blobUrl) URL.revokeObjectURL(blobUrl);
        const ms = performance.now() - t0;
        stat.drawMs += ms;
        if (ms > stat.maxDrawMs) stat.maxDrawMs = ms;
      };

      // Bingkai pertama dan semakan sebelum rakaman
      render(0);
      await drawFrame();
      preflight(ctx, res.w, res.h, scenes[0].bg);

      expSay('Menyediakan pengekod video...', false);
      await warmUpEncoder(expCanvas, mime, res.bps, mime + '@' + res.w);
      if (ex.cancel) throw Object.assign(new Error('dibatalkan'), { cancelled: true });
      // Lukis semula bingkai pertama kerana canvas mungkin disentuh semasa pemanasan
      render(0);
      await drawFrame();

      const stream = expCanvas.captureStream(EXPORT_FPS);
      ex.stream = stream;
      const rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: res.bps });
      ex.recorder = rec;
      const chunks = [];
      let recErr = null;
      rec.ondataavailable = function (e) { if (e.data && e.data.size) chunks.push(e.data); };
      rec.onerror = function (e) { recErr = (e && e.error) || new Error('Ralat MediaRecorder.'); ex.cancel = true; };
      const started = new Promise(function (r) { rec.onstart = r; });
      const stopped = new Promise(function (r) { rec.onstop = r; });
      rec.start(500);
      await started;

      // ---- Gelung rakaman masa nyata ----
      const frameMs = 1000 / EXPORT_FPS;
      const T0 = performance.now();
      let nextAt = T0;
      for (;;) {
        if (ex.cancel) break;
        if (document.hidden) { ex.cancel = true; ex.reason = 'hidden'; break; }
        await nextFrame();
        const now = performance.now();
        if (now < nextAt - 2) continue;
        const t = Math.min(total, (now - T0) / 1000);
        render(t);
        await drawFrame();
        stat.frames++;
        nextAt = Math.max(nextAt + frameMs, now);
        expProgress.value = Math.round((t / total) * 1000);
        expSay('Merakam: ' + fmt(t) + ' / ' + fmt(total) + ' s (' + Math.round((t / total) * 100) + '%)', false);
        stageCaption.textContent = 'Merakam video: ' + Math.round((t / total) * 100) + '%';
        if (t >= total) break;
      }

      if (!ex.cancel) {
        // Tahan bingkai akhir sebentar. Salinan canvas digunakan supaya setiap lukisan murah
        // dan captureStream terus menghasilkan bingkai sehingga rakaman dihentikan.
        const hold = document.createElement('canvas');
        hold.width = res.w; hold.height = res.h;
        hold.getContext('2d').drawImage(expCanvas, 0, 0);
        const tailEnd = performance.now() + EXPORT_TAIL * 1000;
        while (performance.now() < tailEnd && !ex.cancel) {
          await nextFrame();
          ctx.drawImage(hold, 0, 0);
        }
      }
      stat.recordedMs = performance.now() - T0;

      if (rec.state !== 'inactive') rec.stop();
      await stopped;
      if (recErr) throw recErr;
      if (!ex.cancel) stat.coverage = coverage(ctx, res.w, res.h, scenes[scenes.length - 1].bg);

      if (ex.cancel) {
        cancelled = true;
      } else {
        blob = new Blob(chunks, { type: mime.split(';')[0] });
        if (!blob.size) throw new Error('Rakaman tidak menghasilkan sebarang data.');
        if (stat.coverage < 0.01) throw new Error('Bingkai akhir hampir kosong; rakaman tidak sah.');
      }
    } catch (e) {
      if (e && e.cancelled) cancelled = true; else failure = e;
    } finally {
      // Bebaskan semua sumber rakaman, walau berjaya, dibatalkan atau gagal
      try { if (ex.recorder && ex.recorder.state !== 'inactive') ex.recorder.stop(); } catch (e2) { /* abaikan */ }
      if (ex.stream) ex.stream.getTracks().forEach(function (tr) { tr.stop(); });
      img.onload = img.onerror = null;
      img.removeAttribute('src');
      expCanvas.hidden = true;
      expCanvas.width = 1; expCanvas.height = 1;

      // Pulihkan keadaan pratonton; data projek tidak disentuh
      state.mode = saved.mode;
      state.t = saved.t;
      state.showcase = saved.showcase;
      renderStrip();
      render(state.t);
      updateUI();
      exporting = false;
      setLocked(false);
    }

    const intact = serialize() === projectBefore;

    if (failure) {
      expProgress.value = 0;
      expSay(errorText(failure), true);
      return;
    }
    if (cancelled) {
      expProgress.value = 0;
      expSay(ex.reason === 'hidden'
        ? 'Rakaman dibatalkan kerana tab disembunyikan. Biarkan tab kelihatan semasa merakam. Projek anda tidak diubah.'
        : 'Rakaman dibatalkan. Projek anda tidak diubah.', ex.reason === 'hidden');
      return;
    }

    // Semak hasil: muatkan dalam pemain video dan baca resolusi serta tempoh sebenar
    ex.url = URL.createObjectURL(blob);
    expVideo.src = ex.url;
    expVideo.hidden = false;
    const ext = fmtKey === 'mp4' ? 'mp4' : 'webm';
    const result = {
      blob: blob, mime: blob.type, ext: ext, name: VIDEO_BASENAME + '.' + ext,
      width: res.w, height: res.h, expected: total + EXPORT_TAIL,
      recordedMs: stat.recordedMs, frames: stat.frames,
      avgDrawMs: stat.frames ? stat.drawMs / stat.frames : 0, maxDrawMs: stat.maxDrawMs,
      coverage: stat.coverage, projectIntact: intact, videoWidth: 0, videoHeight: 0, videoDuration: NaN
    };
    try {
      await new Promise(function (resolve, reject) {
        if (expVideo.readyState >= 1) { resolve(); return; }
        expVideo.onloadedmetadata = function () { resolve(); };
        expVideo.onerror = function () { reject(new Error('Pemain video tidak dapat memuatkan fail yang dirakam.')); };
      });
      result.videoWidth = expVideo.videoWidth;
      result.videoHeight = expVideo.videoHeight;
      result.videoDuration = await fixDuration(expVideo);
    } catch (e) {
      // Pemain video mungkin disekat oleh persekitaran; fail rakaman masih sah dan boleh dimuat turun
      result.playerFailed = true;
      result.videoDuration = result.recordedMs / 1000;
    }

    ex.result = result;
    const lengthOk = isFinite(result.videoDuration) && Math.abs(result.videoDuration - result.expected) <= Math.max(0.6, result.expected * 0.1 + (result.playerFailed ? 1 : 0));
    result.lengthOk = lengthOk;
    const fpsEff = result.recordedMs ? result.frames / (result.recordedMs / 1000) : 0;
    result.fpsEff = fpsEff;
    expInfo.textContent = '';
    addInfo('Fail', result.name);
    addInfo('Resolusi video', result.playerFailed ? result.width + ' × ' + result.height + ' (pemain video disekat; tidak dapat disahkan)' : result.videoWidth + ' × ' + result.videoHeight);
    addInfo('Tempoh video', isFinite(result.videoDuration) ? fmt(result.videoDuration) + ' s (jangkaan ' + fmt(result.expected) + ' s)' : fmt(result.recordedMs / 1000) + ' s (diukur)');
    addInfo('Saiz', (blob.size / 1048576).toFixed(2) + ' MB');
    addInfo('Format', result.mime);
    addInfo('Bingkai dilukis', result.frames + ' (purata ' + fpsEff.toFixed(1) + ' FPS)');
    addInfo('Masa lukis per bingkai', result.avgDrawMs.toFixed(1) + ' ms (maks ' + result.maxDrawMs.toFixed(0) + ' ms)');
    addInfo('Semakan tempoh', lengthOk ? 'lulus' : 'AMARAN: tempoh tidak sepadan dengan projek');
    addInfo('Semakan kandungan', (result.coverage * 100).toFixed(1) + '% piksel bukan latar: lulus');
    addInfo('Projek asal', intact ? 'tidak berubah' : 'BERUBAH (laporkan ralat ini)');
    expInfo.hidden = false;
    expProgress.value = 1000;
    btnDownloadVideo.disabled = false;
    const slow = fpsEff < EXPORT_FPS * 0.8;
    expSay('Rakaman siap. Semak video di bawah, kemudian tekan Muat Turun.' +
      (slow ? ' Amaran: komputer ini hanya mencapai ' + fpsEff.toFixed(0) + ' FPS. Masa video tepat, tetapi gerakan kurang lancar. Cuba resolusi lebih rendah.' : '') +
      (result.playerFailed ? ' Pemain video dalam persekitaran ini disekat, jadi hasil tidak dapat disemak di sini, tetapi fail boleh dimuat turun.' : '') +
      (lengthOk ? '' : ' Amaran: tempoh video tidak sepadan dengan projek. Sila eksport sekali lagi.'), slow || !lengthOk || !!result.playerFailed);
  }

  function cancelExport() {
    if (!exporting) return;
    ex.cancel = true;
    expSay('Membatalkan rakaman...', false);
  }

  async function downloadVideo() {
    const r = ex.result;
    if (!r) return;
    try {
      if (window.claude && typeof window.claude.use === 'function') {
        const dl = await window.claude.use('downloads');
        if (dl) {
          await dl.save({ filename: r.name, data: r.blob });
          expSay('Video dihantar untuk disimpan. Sahkan dalam dialog yang dipaparkan.', false);
          return;
        }
      }
    } catch (e) {
      if (e && e.code === 'declined') { expSay('Muat turun dibatalkan.', false); return; }
      expSay('Muat turun melalui Claude tidak berjaya. Klik kanan pada pemain video dan pilih Simpan video sebagai.', true);
      return;
    }
    try {
      const a = document.createElement('a');
      a.href = ex.url;
      a.download = r.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      expSay('Muat turun dimulakan: ' + r.name + '. Jika tiada fail, klik kanan pada pemain video dan pilih Simpan video sebagai.', false);
    } catch (e) {
      expSay('Muat turun disekat. Klik kanan pada pemain video dan pilih Simpan video sebagai.', true);
    }
  }

  btnExport.addEventListener('click', startExport);
  btnCancelExport.addEventListener('click', cancelExport);
  btnDownloadVideo.addEventListener('click', downloadVideo);
  document.addEventListener('visibilitychange', function () {
    if (exporting && document.hidden) { ex.cancel = true; ex.reason = 'hidden'; }
  });
  window.addEventListener('pagehide', function () { if (ex.url) URL.revokeObjectURL(ex.url); });

  /* =====================================================================
     FASA 1E: personalisasi (warna, huruf besar/kecil) dan identiti pembangun
     ===================================================================== */
  // Maklumat tetap aplikasi: tidak disimpan dalam projek dan tidak boleh diubah melalui teks adegan
  const DEVELOPER = Object.freeze({ name: 'Nuraidah binti Mustapah', role: 'Pembangun PencilMotion EDU' });

  const sceneCase = $('#sceneCase');
  const charWarn = $('#charWarn');
  const btnBgAll = $('#btnBgAll');
  const contrastMsg = $('#contrastMsg');
  const btnFixContrast = $('#btnFixContrast');
  const optCredit = $('#optCredit');

  creditText.textContent = 'Dibangunkan oleh ' + DEVELOPER.name;
  $('#footCredit').textContent = 'Dibangunkan oleh ' + DEVELOPER.name;
  $('#aboutName').textContent = DEVELOPER.name;
  $('#aboutRole').textContent = DEVELOPER.role;

  function applyCredit() {
    creditG.setAttribute('visibility', settings.credit ? 'visible' : 'hidden');
    optCredit.checked = !!settings.credit;
  }

  function warnText(o) {
    const parts = [];
    if (o.unsupported && o.unsupported.length) parts.push('Amaran: aksara berikut tidak dapat dilukis dan dilangkau dalam animasi: ' + o.unsupported.join(' ') + '. Teks anda tidak diubah.');
    if (o.mapped && o.mapped.length) parts.push('Huruf beraksen dilukis tanpa tanda aksen: ' + o.mapped.join(' ') + '.');
    return parts.join(' ');
  }

  function updateCharWarn() {
    const sc = scenes[state.sel];
    charWarn.textContent = sc ? warnText(normalizeText(sc.text, sc.caseMode)) : '';
  }

  const lin = (c) => { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
  function relLum(hex) {
    const n = parseInt(hex.slice(1), 16);
    return 0.2126 * lin((n >> 16) & 255) + 0.7152 * lin((n >> 8) & 255) + 0.0722 * lin(n & 255);
  }
  const contrastRatio = (a, b) => { const l1 = relLum(a), l2 = relLum(b); return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05); };

  // Keterbacaan: beri amaran dan cadangan; warna pilihan pengguna tidak diubah tanpa tindakan pengguna
  function updateContrast() {
    const sc = scenes[state.sel];
    if (!sc) return;
    const r = contrastRatio(sc.ink, sc.bg);
    const low = r < 3;
    contrastMsg.hidden = !low;
    btnFixContrast.hidden = !low;
    if (low) {
      contrastMsg.textContent = 'Amaran keterbacaan: kontras warna tulisan dengan latar hanya ' + r.toFixed(1) +
        ':1. Warna pilihan anda tidak diubah. Tekan Laraskan warna tulisan untuk menukar kepada ' + (relLum(sc.bg) < 0.4 ? 'putih' : 'hitam') + '.';
    }
  }

  function parseHex(v) {
    v = String(v).trim();
    if (v[0] !== '#') v = '#' + v;
    if (/^#[0-9a-fA-F]{3}$/.test(v)) v = '#' + v[1] + v[1] + v[2] + v[2] + v[3] + v[3];
    return /^#[0-9a-fA-F]{6}$/.test(v) ? v.toLowerCase() : null;
  }

  sceneCase.addEventListener('change', function () {
    const sc = scenes[state.sel];
    sc.caseMode = sceneCase.value;
    updateCharWarn();
    if (commitScene(sc) === 'ok') { recomputeProject(); renderList(); renderStrip(); persist(); showcaseSelected(); }
  });

  btnBgAll.addEventListener('click', function () {
    const bg = scenes[state.sel].bg;
    scenes.forEach(function (sc) { sc.bg = bg; recolorScene(sc); });
    renderList(); renderStrip(); updateContrast(); render(state.t); persist();
    say('Warna latar digunakan pada semua ' + scenes.length + ' adegan.', false);
  });

  btnFixContrast.addEventListener('click', function () {
    const sc = scenes[state.sel];
    sc.ink = relLum(sc.bg) < 0.4 ? '#ffffff' : '#111111';
    recolorScene(sc);
    refreshSwatches('ink'); renderList(); updateContrast(); render(state.t); persist();
  });

  optCredit.addEventListener('change', function () {
    settings.credit = optCredit.checked;
    applyCredit();
    persist();
  });

  /* ---------- Mula ---------- */
  buildSwatches('bg');
  buildSwatches('ink');
  buildSwatches('pencil');

  const stored = readStored();
  loadProject(stored || parseProject(SAMPLE));
  if (stored) projSay('Projek terakhir anda dipulihkan. Tekan Projek contoh untuk memuatkan semula contoh asal.', false);

  initExportUI();

  const reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!reduce) replay();

  // Bantuan ujian dalam konsol: PencilMotion.seek(12.5)
  window.PencilMotion = {
    seek: seek, play: play, pause: pause, replay: replay,
    state: state,
    scenes: function () { return scenes.map(function (s) { return Object.assign({}, s); }); },
    info: function () {
      return {
        total: total, starts: starts.slice(), mode: state.mode, sel: state.sel,
        scenes: scenes.map(function (s, i) { return { id: s.id, dur: cs(i).dur, strokes: cs(i).strokes.length, T: cs(i).T, text: cs(i).text, caseMode: cs(i).caseMode, lines: cs(i).lineBoxes, unsupported: cs(i).unsupported, mapped: cs(i).mapped, count: cs(i).count }; })
      };
    },
    exportJSON: serialize,
    importJSON: importFrom,
    snapshot: snapshotSVG,
    exportState: function () {
      return {
        exporting: exporting,
        recorderState: ex.recorder ? ex.recorder.state : null,
        tracks: ex.stream ? ex.stream.getTracks().map(function (t) { return t.readyState; }) : [],
        support: { ok: support.ok, webm: support.webm, mp4: support.mp4 }
      };
    },
    lastExport: function () {
      const r = ex.result;
      if (!r) return null;
      return {
        name: r.name, mime: r.mime, size: r.blob.size, width: r.width, height: r.height,
        videoWidth: r.videoWidth, videoHeight: r.videoHeight, videoDuration: r.videoDuration,
        expected: r.expected, recordedMs: r.recordedMs, frames: r.frames, fpsEff: r.fpsEff,
        avgDrawMs: r.avgDrawMs, maxDrawMs: r.maxDrawMs, coverage: r.coverage, projectIntact: r.projectIntact, lengthOk: r.lengthOk, playerFailed: !!r.playerFailed
      };
    }
  };
})();
